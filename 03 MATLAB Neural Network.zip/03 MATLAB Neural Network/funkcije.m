function o = purelin(wx,b)	% linearna aktivaciona f-ja cols = size(wx,2);
o = wx + b*ones(1,cols);

function o = tansig(wx,b)	% tangensni sigmoid f-ja z = purelin(wx,b);
o = 2 ./ (1+exp(-2*z)) - 1;

function d = deltatan(y,d,w)
d = 0.5*(1 - (y.*y)) .* (w'*d);

function [dw,db] = learnbp(x,d,eta)
q = eta*d;
dw = q * x';
cols = size(x,2);
db = q * ones(cols,1);


% obucavajuci skup: XOR problem, ali može i nešto teže : ) 
X = [-1 -1 1 1 -1 1 -1 1];	% ulazi
Y = [-1  1 1 -1];	% izlazi


% inicijalizacija tezina, bias-a (S1==broj skrivenih celija) 
[R,Q] = size(X);  
S1 = 5; 
[S3,Q] = size(Y); 
S2 = 2;
W1 = rand(S1,R) * .5 - .25; 
B1 = rand(S1,1) * .5 - .25; 
W2 = rand(S2,S1)* .5 - .25;
B2 = rand(S2,1) * .5 - .25; 
W3 = rand(S3,S2)* .5 - .25;
B3 = rand(S3,1) * .5 - .25;


eps = 0.02;	% tacnost racunanja
eta = 0.2;	% koef. brzine obucavanja
error = [];	% vektor gresaka tokom obuke


for i=1:5000
% prolaz u napred
Y1 = tansig(W1*X,B1);
Y2 = tansig(W2*Y1,B2);
Y3 = purelin(W3*Y2,B3);

% greška
E = Y - Y3;
SE = mean(sum(E.*E));
error = [error SE];

% provera kraja
if SE < eps, break, end

% ...

% obuka
D3 = E;
D2 = deltatan(Y2,D3,W3);
D1 = deltatan(Y1,D2,W2);
[dW1,dB1] = learnbp(X,D1,eta);
[dW2,dB2] = learnbp(Y1,D2,eta);
[dW3,dB3] = learnbp(Y2,D3,eta);
W1 = W1 + dW1; B1 = B1 + dB1;
W2 = W2 + dW2; B2 = B2 + dB2;
W3 = W3 + dW3; B3 = B3 + dB3;

% ispis
if rem(i,50) == 0, disp([i, SE]), 
end
end

disp([i,SE])	% konacan ispis
plot(error)
