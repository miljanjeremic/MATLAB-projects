function [Max_Car_Score ] = ahp_simple()
%% AHP analytical hierarchy process, simple example
%

%  To run, just load script into editor and hit the run key!
%
% This simple by example function (with default values) gives the basic 
% elements of the Analytical Hierarchial Process (AHP) for decision making 
% to include matrix formulations, pairwise analysis, calculating 
% eigenvectors, and determining the final 'best' decision based on criteria. 
%% Example problem:
% Situation: I wish to purchase a car (civic, focus, corolla, BMW318)
% and select the best car based on criteria (style, reliability,
% and fuel economy). To make the best car purchase decision, I will use
% AHP with the following:
%         alternatives:  civic, focus, corolla, BMW318
%         criteria:      style, reliability, fuel economy
%%---------------------------------------------
%% Problem formulation:
clear all; close all; clc;
%% Step 1: Criteria Matrix and Criteria Eigenvector
% 
% Since this part is subjective, I give reliability, style and fuel economy
% importance. Thus I will rank these as follows (subjective qualitative):
% Reliability (R) is 2 time as important as style (S)
% Style (S) is 3 times as important as fuel economy (FE)
% Reliability (R) is 4 times as important as fuel economy (FE)
% Using Scale:
%   1-equal, 3-moderate, 5-strong, 7-very strong, 9-extreme

%%%disp('Criteria Pairwise Comparison Matrix PCM');
disp('PCM matrica kriterijuma');

% pairwise comparision of each criteria to each criteria
% denoted as the matrix PCM
%      (S)   (R)  (FE)    
%PCM= [ 1	0.33	0.2; 3	1	0.5; 5	2	1;];      % (FE-fuel economy)

PCM= [1 2 3 3 3; 1/2 1 2 3 3; 1/3 1/2 1 3 3; 1/3 1/3 1/3 1 3; 1/3 1/3 1/3 1/3 1;];
ePCM=eig(PCM)
   
   %%%ePCM=calc_eig(PCM);
%%
  
%% Step 2: Alternatives Matrix and Alternatives Eigenvectors 
% Alternative Ranking (Car to Car on Style, Reliability, and Fuel)
% Compaire each car to each car denoted as the alternatives 
% (civic, focus, corolla, BMW318)
% In the terms of style, reliability, and fuel economy using
% pairwise comparison for qualitative and normalization for quantitative
% 
%   example of the style comparison
%
%                    civic        focus         corolla         BMW318
% civic               1/1         1/4            4/1            1/6
% focus               4/1         1/1            4/1            1/4
% corolla             1/4         1/4            1/1            1/5
% BMW318              6/1         4/1            5/1            1/1
%% Compare Mo?:

%%%disp('Style Comparison: Alternatives Qualitative Pairwise');
ACM_K1 =[ 1 1 1 1 1; 1 1 1 1 1; 1 1 1 1 1; 1 1 1 1 1; 1 1 1 1 1;];
eACM_K1 = calc_eig(ACM_K1); % calculate eigenvector on qualitative matrix

%%
%% Compare Cena:

%%%disp('Reliability Comparison: Alternatives Qualitative Pairwise');
ACM_K2 = [ 1 1 3 3 1; 1 1 3 3 1; 1/3 1/3 1 1 3; 1/3 1/3 1 1 3; 1 1 1/3 1/3 1;];
eACM_K2 = calc_eig(ACM_K2); % calculate eigenvector on qualitative matrix
%% 
%% Compare Filter:
%%%disp('Fuel Economy Comparision: Alternatives Quantitative (MPG)');
% given MPG data for each vehicle, create a fuel economy matrix
%  MPG matrix    
 cv = 34;   % civic
 sa = 27;   % focus
 es = 24;   % corolla
 cl = 28;   % BMW318
 
ACM_K3 = [1 1 1 1 5; 1 1 1 1 5; 1 1 1 1 5; 1 1 1 1 1/5; 1/5 1/5 1/5 5 1;];   
eACM_K3  = calc_eig(ACM_K3);  % normalize quantitative type data      
 %%
 %% Compare Gabarit:
ACM_K4 = [1 1 1 1 1; 1 1 1 1 1; 1 1 1 1 1; 1 1 1 1 1; 1 1 1 1 1;];
eACM_K4  = calc_eig(ACM_K4);  % normalize quantitative type data  
 
 %% Compare Delovi:
 ACM_K5 = [1 1/9 1/3 1/3 1/5; 9 1 2/9 2/9 2/9; 3 4.54 1 2/9 2/9; 3 4.54 4.54 1 2/9; 5 4.54 4.54 4.54 1;];     
 eACM_K5  = calc_eig(ACM_K5);  % normalize quantitative type data  
 
 disp('Hit space key to continue to winner of benefits')
        pause()   
        clc;
    
 %% Step 3:  Calculate Final Answer and Determine winner
 % construc a matrix of eigenvectors calculated above for each criteria
 % eigenvectors: Style   Reliability   Fuel-econ
 eM         =   [eACM_K1   eACM_K2   eACM_K3   eACM_K4   eACM_K5  ];
 
 % multiply eigenvector matrix by eigenvector of criteria to obtain
 % scores for each car based on criteria and car-to-car comparisons
 disp('Padavine prikazane za delove Srbije: Isto�?na Srbija, Zapadna Sebija, Vojvodina, Južna Srbija, Centralna Srbija')
 Padavine_Scores = eM * ePCM
 
 % Best Maska as a factor of benefits (criteria)
 %disp('Winning Maska based on benefits, BMW318')
 Najvise_padavina = max(Padavine_Scores)
 
 disp(Najvise_padavina)
 disp('Prikaz vrednosti po oblastima')
 disp(Padavine_Scores)
 
%% sub-function on calculating eigenvectors
    function [eigvect ] = calc_eig(M) 
        %Convert pairwise matrix (PCM) into ranking of criteria (RCM) using
        %eignevectors (reference: the analytical hierarchy process, 1990,
        % Thomas L. Saaty
        
        % Note: A simple/fast way to solve for the eigenvectors are:
        % 1. Raise pairwise matrix to powers that are successively squared
        % 2. Sum the rows and normalize summed rows.
        % 3. Stop when the difference between the sums in two consecutive
        %    iterations is smaller than tolerance.
        c=1;
        [m n]=size(M);
        nrM(m,:)=10000; tolmet=0; tolerance=.035;
        while tolmet<1 
            c=c+1;                                        % counter
            M=M^2;                                        % pairwise matrix^2
            sr1M = sum(M,2);                              % sum rows
            sr2M = sum(sr1M);                             % sum of sum rows
            nrM(:,c) = sr1M./sr2M;                        % normalize
            tol(c)=sum(abs(nrM(:,c) - nrM(:,c-1)));       % calc. tolerance
             if tol < tolerance                    % tolerance met?
                tolmet=1;                          % tolerance met, stop iterations
             elseif sum(sum(M))>=10e30 
                 tolmet=1;                         % tolerance unlikely, stop iterations
             end
        end
        disp('Eigenvector of matrix');
        eigvect = nrM(:,end); % eigenvector of PCM
    end
%% sub-function to normalize a vector (0-1)
    function [normvect ] = calc_norm(M) 
        sM = sum(M);
        normvect = M./sM;
        disp('Normalizovana matrica');
    end
end